from django.apps import AppConfig


class HabitsConfig(AppConfig):
    name = 'habits'
