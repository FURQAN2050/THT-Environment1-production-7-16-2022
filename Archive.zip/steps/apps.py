from django.apps import AppConfig


class StepsConfig(AppConfig):
    name = 'steps'
