from django.apps import AppConfig


class PresentationpageConfig(AppConfig):
    name = 'presentationpage'
