from django.apps import AppConfig


class DjangocmsvideoConfig(AppConfig):
    name = 'djangocmsvideo'
