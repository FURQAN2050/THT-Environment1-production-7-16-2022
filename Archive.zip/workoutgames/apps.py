from django.apps import AppConfig


class WorkoutgamesConfig(AppConfig):
    name = 'workoutgames'
