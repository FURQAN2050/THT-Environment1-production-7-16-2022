from django.apps import AppConfig


class FooterConfig(AppConfig):
    name = 'footer'
