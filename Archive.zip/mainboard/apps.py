from django.apps import AppConfig


class MainboardConfig(AppConfig):
    name = 'mainboard'

