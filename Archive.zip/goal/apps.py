from django.apps import AppConfig


class GoalConfig(AppConfig):
    name = 'goal'
