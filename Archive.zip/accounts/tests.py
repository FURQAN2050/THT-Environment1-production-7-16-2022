from django.test import TestCase
from . import models

import datetime

# Create your tests here.

# Create a female teacher with traditional case variables

class TeacherTestCaseFemaleTraditional(TestCase):


    def setUp(self):

        self.user = models.User.objects.create_user(username='testuser', password='12345', isDistrictManager=False)

        self.districtO = models.Districts.objects.create(
            district = "TestDistrict",
            emailDomain = "test.com"
        )

        self.team = models.Teams.objects.create(
            team = 'Green',
            district = self.districtO,
            color = 'Green'
        )

        self.teacher = models.Teacher.objects.create(
            user = self.user,
            team = self.team,
            district = self.districtO,
            gender = models.Teacher.GENDER[1],
            birthday = datetime.date(1987, 5, 19),
            weight = 155.76,
            height = 69.68,
            sysBloodPressure = 120,
            diasBloodPressure = 70,
            cholesterol = 100,
            bmi = 20,
            waistSize = 35,
            isPrediabetic = False,
            isDiabetic = False,
            activityLevel = models.Teacher.MODERATE_ACTIVE_CONST,
            isFatLoss = True,
            isMuscleGain = False
        )

        self.teacher.calculateBmr()
        self.teacher.calculateTotalDailyEnergyExp()
        self.teacher.calculateConsumptionCal()
        self.teacher.calculateProtein()
        self.teacher.calculateCarbs()
        self.teacher.calculateFats()


    def test_check_bmr(self):

        self.assertTrue((self.teacher.bmr - 1493.25) < 5 and
                        (self.teacher.bmr - 1493.25) > -5)



    def test_check_TDEE(self):

        self.assertTrue((self.teacher.totalDailyEnergyExp - 2314) < 5 and
                        (self.teacher.totalDailyEnergyExp - 2314) > -5)


    def test_check_EnergyConsumption(self):


        self.assertTrue((self.teacher.energyConsumption - 1814) < 5 and
                        (self.teacher.energyConsumption - 1814) > -5)


    
    def test_check_proteins(self):
        

        self.assertTrue((self.teacher.proteins - 145) < 5 and
                        (self.teacher.proteins - 145) > -5)


        
    def test_check_carbs(self):

        self.assertTrue((self.teacher.carbs - 172.25) < 5 and
                        (self.teacher.carbs - 172.25) > -5)



    def test_check_fats(self):

        self.assertTrue((self.teacher.fats - 60.44) < 5 and
                        (self.teacher.fats - 60.44) > -5)





# Create a female teacher with traditional case variables

class TeacherTestCaseMaleTraditional(TestCase):


    def setUp(self):

        self.user = models.User.objects.create_user(username='testuser', password='12345', isDistrictManager=False)

        self.districtO = models.Districts.objects.create(
            district = "TestDistrict",
            emailDomain = "test.com"
        )

        self.team = models.Teams.objects.create(
            team = 'Green',
            district = self.districtO,
            color = 'Green'
        )

        self.teacher = models.Teacher.objects.create(
            user = self.user,
            team = self.team,
            district = self.districtO,
            gender = models.Teacher.GENDER[0],
            birthday = datetime.date(1997, 5, 19),
            weight = 165,
            height = 72,
            sysBloodPressure = 120,
            diasBloodPressure = 70,
            cholesterol = 100,
            bmi = 20,
            waistSize = 35,
            isPrediabetic = False,
            isDiabetic = False,
            activityLevel = models.Teacher.LIGHT_ACTIVE_CONST,
            isFatLoss = False,
            isMuscleGain = True
        )

        self.teacher.calculateBmr()
        self.teacher.calculateTotalDailyEnergyExp()
        self.teacher.calculateConsumptionCal()
        self.teacher.calculateProtein()
        self.teacher.calculateCarbs()
        self.teacher.calculateFats()


    def test_check_bmr(self):

        self.assertTrue((self.teacher.bmr - 1786) < 5 and
                        (self.teacher.bmr - 1786) > -5)



    def test_check_TDEE(self):

        self.assertTrue((self.teacher.totalDailyEnergyExp - 2456) < 5 and
                        (self.teacher.totalDailyEnergyExp - 2456) > -5 )



    def test_check_EnergyConsumption(self):

        self.assertTrue((self.teacher.energyConsumption - 2706) < 5 and
                        (self.teacher.energyConsumption - 2706) > -5)


    
    def test_check_proteins(self):

        self.assertTrue((self.teacher.proteins - 216.48) < 5 and
                        (self.teacher.proteins - 216.48) > -5)


        
    def test_check_carbs(self):

        self.assertTrue((self.teacher.carbs - 257.07) < 5 and
                        (self.teacher.carbs - 257.07) > -5)



    def test_check_fats(self):

        self.assertTrue((self.teacher.fats - 90.2) < 5 and
                        (self.teacher.fats - 90.2) > -5)

