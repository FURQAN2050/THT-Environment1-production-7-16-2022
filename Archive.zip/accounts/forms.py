from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives
from django.conf import settings

from .tokens import account_activation_token
from .models import User
from .models import Districts
from .models import Teacher
from .models import Subscriptions


# WORKON: Make sure these processes are correct
# WORKON: Add extra questions to form
# WORKON: If on keto diet, do not calculate macros yet

# Sign up form extended. Sends confirmation email and creates a teacher

class UserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = (
            "username",
            "email",
            "password1",
            "password2",
            "first_name",
            "last_name"
        )

    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.is_active = False

        if commit:
            user.save()

            # Send confirmation email to user to activate account

            mail_subject = "Activate your Healthy Teacher Account"

            messagehtml = render_to_string('acc_active_email.html', {
                    'user': user,
                    'domain': settings.SITE_HOST,
                    'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                    'token':account_activation_token.make_token(user),
                })

            messageplain = render_to_string('acc_active_email_plain.html', {
                    'user': user,
                    'domain': settings.SITE_HOST,
                    'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                    'token':account_activation_token.make_token(user),
                })

            to_email = self.cleaned_data['email']

            email = EmailMultiAlternatives(
                mail_subject, messageplain, to=[to_email]
            )
            email.attach_alternative(messagehtml, "text/html")

            email.send()

        if user.isDistrictManager == False:
            

            if Districts.objects.filter(emailDomain__icontains=self.cleaned_data['email'].split('@')[1]).exists():
            
                teacher = Teacher(user = user, district = Districts.objects.get(emailDomain__icontains=self.cleaned_data['email'].split('@')[1]))
                teacher.save()

            else:

                teacherDistrict = self.createIndependentDistrict(self.cleaned_data['email'])
                teacher = Teacher(user = user, district = teacherDistrict)
                teacher.save()


            
            if teacher.district.isIndependent == True:

                teacher.isIndividualAccount = True

            else:

                teacher.isIndividualAccount = False

            teacher.save()
            
            
        return user

    def createIndependentDistrict(self, email):

        domain = self.cleaned_data['email'].split('@')[1]
        districtName = domain.split('.')[0]

        district = Districts(district = districtName, emailDomain = domain, isIndependent = True)

        district.save()

        return district


    def clean(self):
        
        if User.objects.filter(username__exact=self.cleaned_data['username']).exists():
            raise forms.ValidationError(
                "Username already exists"
            )
        
        

        if User.objects.filter(email__exact=self.cleaned_data['email']).exists():
            raise forms.ValidationError(
                "Email address already exists"
            )

        
        return self.cleaned_data
                

# Form to select a team for user

class FinishSignUpForm(forms.Form):

    team = forms.CharField(max_length=50)

class SubscribeForm(forms.Form):

    order = forms.ModelChoiceField(queryset=Subscriptions.objects)

class HealthDataForm(forms.Form):

    GENDER = [('Male', 'Male'), ('Female', 'Female')]
    CLOSED = [('No', 'No'), ('Yes', 'Yes')]

    GENDER_R = ['Male', 'Female']
    CLOSED_R = ['No', 'Yes']
    
    gender = forms.ChoiceField(choices=GENDER)
    birthday = forms.DateField()
    weight = forms.FloatField()
    height = forms.FloatField()
    sysBloodPressure = forms.FloatField(required=False)
    diasBloodPressure = forms.FloatField(required=False)
    cholesterol = forms.FloatField(required=False)
    waistsize = forms.FloatField()
    isPrediabetic = forms.ChoiceField(choices=CLOSED)
    isDiabetic = forms.ChoiceField(choices=CLOSED)
    isKeto = forms.BooleanField(required=False)
    lastDiet = forms.CharField(max_length=30, required=False)
    nutritionDetails = forms.CharField(max_length=1000, required=False)
    beforePicture = forms.ImageField(required=False)
    currentPicture = forms.ImageField(required=False)
    

class MacronutrientsForm(forms.Form):

    activityLevel = forms.ChoiceField(choices=Teacher.ACTIVITY_LEVEL)
    goal = forms.ChoiceField(choices=Teacher.GOAL_OPTIONS)


class EditMyProfileForm(forms.Form):
    
    profilePicture = forms.ImageField(required=False)
    username = forms.CharField(max_length=50)
    email = forms.CharField(max_length=80)
    first_name = forms.CharField(max_length=50)
    last_name = forms.CharField(max_length=50)

